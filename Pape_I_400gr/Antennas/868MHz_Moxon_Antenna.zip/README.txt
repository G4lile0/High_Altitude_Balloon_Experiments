                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2124434
868MHz Moxon Antenna by DzikuVx is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

868MHz Moxon rectangle antenna with mounting system. Usable for telemetry, long range radio systemes (LRS) and other purposes.

This design can be mounted either on a tripod with snap mount or on radio carrying handle. There are two versions of carrying handle mount. Check which one suits you better.

# Print Settings

Printer: Malyan M150
Rafts: Doesn't Matter
Supports: No
Resolution: 0.2mm
Infill: 20%

Notes: 
Insert 0.8mm copper wire into groves and secure it with thin layer of epoxy.
Antenna cable (RG316) can be attached with zip ties.
Use M3x8 screws to attach arm and clip.

Clip elements should be glued together with CA. Some sanding might be required.

Frequency tuning:

For TBS Crossfire and FrSky R9 systems, some tuning might be required. To tune for 869MHz slightly shorter copper wire should be used. With lengths like in tuning picture I got VSWR 1.3


Cable to the TX should be around 22cm long with SMA connector included